import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import axios from "axios";

// SIMPLE XOR ENCRYPTION FOR WIRE DATA
const SECRET_SALT = "SERIES_APP_2024";

function encryptValue(text: string): string {
  if (!text) return "";
  const key = SECRET_SALT;
  let result = "";
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return Buffer.from(result).toString("base64");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  const API_BASE = process.env.EXTERNAL_API_BASE || 'https://series.albesriali03.workers.dev/';

  // API Proxy Routes
  // 1. Categories
  app.get("/api/v1/categories", async (req, res) => {
    try {
      const response = await axios.get(`${API_BASE}?action=categories`);
      // Obfuscate URLs before sending to client
      if (response.data && response.data.data) {
        response.data.data = response.data.data.map((cat: any) => ({
          ...cat,
          url: encryptValue(cat.url)
        }));
      }
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ status: false, message: "Server Error" });
    }
  });

  // 2. Series by Category
  app.get("/api/v1/series", async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) return res.status(400).json({ status: false });
      
      const response = await axios.get(`${API_BASE}?action=series&url=${encodeURIComponent(url as string)}`);
      if (response.data && response.data.data) {
        response.data.data = response.data.data.map((s: any) => ({
          ...s,
          url: encryptValue(s.url),
          image: s.image ? encryptValue(s.image) : ""
        }));
      }
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ status: false });
    }
  });

  // 3. Episodes
  app.get("/api/v1/episodes", async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) return res.status(400).json({ status: false });
      
      const response = await axios.get(`${API_BASE}?action=episodes&url=${encodeURIComponent(url as string)}`);
      if (response.data && response.data.data) {
        response.data.data = response.data.data.map((ep: any) => ({
          ...ep,
          url: encryptValue(ep.url)
        }));
      }
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ status: false });
    }
  });

  // 4. Play URL
  app.get("/api/v1/play", async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) return res.status(400).json({ status: false });
      
      const response = await axios.get(`${API_BASE}?action=play&url=${encodeURIComponent(url as string)}`);
      if (response.data && response.data.player_url) {
        response.data.player_url = encryptValue(response.data.player_url);
      }
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ status: false });
    }
  });

  // Firebase Config with obfuscation
  app.get("/api/v1/config/firebase", (req, res) => {
    const config = {
      apiKey: process.env.FIREBASE_API_KEY || "AIzaSyAnYkOnP2XWfaKrXXvTO3Euq7s-pl9QGKg",
      authDomain: process.env.FIREBASE_AUTH_DOMAIN || "chat-516a8.firebaseapp.com",
      databaseURL: process.env.FIREBASE_DATABASE_URL || "https://chat-516a8-default-rtdb.firebaseio.com",
      projectId: process.env.FIREBASE_PROJECT_ID || "chat-516a8",
      storageBucket: process.env.FIREBASE_STORAGE_BUCKET || "chat-516a8.firebasestorage.app",
      messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || "276393305302",
      appId: process.env.FIREBASE_APP_ID || "1:276393305302:web:12f90a55d7c13a4c57d577"
    };

    // Encrypt each value
    const securedConfig = Object.fromEntries(
      Object.entries(config).map(([key, val]) => [key, encryptValue(val)])
    );

    res.json({ status: true, data: securedConfig });
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
