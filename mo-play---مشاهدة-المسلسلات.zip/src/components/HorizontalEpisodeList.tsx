import React, { useRef, useEffect } from 'react';
import { Episode } from '../services/firebase';
import { cn } from '../lib/utils';
import { CheckCircle2 } from 'lucide-react';
import { progressService } from '../services/progressService';

interface HorizontalEpisodeListProps {
  episodes: Episode[];
  currentIndex: number;
  seriesImage: string;
  seriesId: string;
  onSelect: (ep: Episode, index: number) => void;
}

export default function HorizontalEpisodeList({
  episodes,
  currentIndex,
  seriesImage,
  seriesId,
  onSelect,
}: HorizontalEpisodeListProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Scroll to active episode
    if (scrollRef.current) {
      const activeElement = scrollRef.current.querySelector('[data-active="true"]');
      if (activeElement) {
        activeElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }
  }, [currentIndex]);

  return (
    <div 
      ref={scrollRef}
      className="flex gap-3 overflow-x-auto pb-4 pt-2 custom-scrollbar"
    >
      {episodes.map((ep, idx) => {
        const isWatched = progressService.isWatched(seriesId, idx);
        const isActive = currentIndex === idx;

        return (
          <button
            key={idx}
            data-active={isActive}
            onClick={() => onSelect(ep, idx)}
            className={cn(
              "flex-shrink-0 w-32 rounded-xl overflow-hidden border-2 transition-all group",
              isActive ? "border-primary scale-105" : "border-white/5 bg-zinc-900 hover:border-white/20"
            )}
          >
            <div className="relative aspect-video w-full">
              <img 
                src={seriesImage} 
                alt={ep.title} 
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                <span className="text-2xl font-black text-white drop-shadow-lg">
                  {idx + 1}
                </span>
              </div>
              {isActive && (
                <div className="absolute top-1 left-1 bg-primary text-[8px] font-black px-1.5 py-0.5 rounded shadow-lg animate-pulse">
                  PLAYING
                </div>
              )}
            </div>
          </button>
        );
      })}
    </div>
  );
}
