import React, { useState, useEffect, useRef } from 'react';
import { Search, Heart, User, X, Mic, Wand2, ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

export default function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const navigate = useNavigate();
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.lang = 'ar-SA';
      recognitionRef.current.continuous = false;
      
      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
        setIsListening(false);
        // Auto search after voice
        setTimeout(() => {
          if (transcript.trim()) {
            navigate(`/?q=${encodeURIComponent(transcript)}`);
            setIsSearchOpen(false);
          }
        }, 800);
      };

      recognitionRef.current.onend = () => setIsListening(false);
      recognitionRef.current.onerror = () => setIsListening(false);
    }
  }, [navigate]);

  const toggleVoiceSearch = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      setSearchQuery('');
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?q=${encodeURIComponent(searchQuery)}`);
      setIsSearchOpen(false);
    }
  };

  return (
    <>
      <header className="sticky top-0 z-40 flex items-center justify-between px-4 sm:px-8 py-4 sm:py-6 bg-black/40 backdrop-blur-xl border-b border-white/5">
        <Link to="/" className="flex items-center gap-2 sm:gap-3">
          <div className="text-primary text-xl sm:text-3xl font-black italic tracking-tighter uppercase">حكايتنا</div>
        </Link>

        <div className="hidden lg:flex items-center gap-8 text-[12px] font-bold tracking-[0.2em] text-zinc-400 uppercase">
          <Link to="/" className="text-white border-b-2 border-primary pb-1">الرئيسية</Link>
          <span className="hover:text-white cursor-pointer transition-colors">مسلسلات</span>
          <span className="hover:text-white cursor-pointer transition-colors">أفلام</span>
          <span className="hover:text-white cursor-pointer transition-colors">المفضلة</span>
        </div>

        <div className="flex items-center gap-3 sm:gap-6">
          <button 
            onClick={() => setIsSearchOpen(true)}
            className="w-10 h-10 rounded-full flex items-center justify-center bg-white/5 text-zinc-400 hover:text-primary transition-all border border-white/5"
          >
            <Search className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 sm:gap-4">
            <Link to="/favorites" className="p-1.5 sm:p-2 text-zinc-400 hover:text-primary transition-colors hidden sm:block">
              <Heart className="w-5 h-5" />
            </Link>
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-[10px] font-black italic shadow-lg shadow-primary/40">
              M
            </div>
          </div>
        </div>
      </header>

      {/* Prominent Search Overlay */}
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSearchOpen(false)}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-3xl flex flex-col items-center justify-center p-6 sm:p-20"
          >
            <button 
              onClick={() => setIsSearchOpen(false)}
              className="absolute top-6 right-6 sm:top-12 sm:right-12 w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-zinc-400 hover:text-white transition-all border border-white/10 z-[101]"
            >
              <X className="w-6 h-6" />
            </button>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl text-center space-y-8"
            >
              <h2 className="text-4xl sm:text-6xl font-black italic text-white/20 uppercase tracking-widest hidden sm:block">
                ابحث عن قصتك
              </h2>

              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary/50 to-orange-600/50 rounded-[40px] blur opacity-20 group-focus-within:opacity-40 transition-opacity"></div>
                <form 
                  onSubmit={handleSearch}
                  className="relative flex items-center bg-zinc-900/40 border border-white/10 rounded-[32px] p-2 transition-all group-focus-within:border-primary/50"
                >
                  <Search className="w-6 h-6 text-zinc-500 ml-6" />
                  <input
                    autoFocus
                    type="text"
                    dir="rtl"
                    placeholder="اسم المسلسل، البطل، أو النوع..."
                    className="flex-1 bg-transparent border-none outline-none text-white text-xl sm:text-4xl font-bold py-4 px-4 placeholder-zinc-700 italic"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={toggleVoiceSearch}
                    className={`w-12 sm:w-16 h-12 sm:h-16 rounded-[24px] flex items-center justify-center transition-all ${isListening ? 'bg-red-600 text-white animate-pulse' : 'bg-white/5 text-zinc-400 hover:bg-white/10 hover:text-primary'}`}
                  >
                    <Mic className="w-6 h-6" />
                  </button>
                </form>
              </div>

              {isListening && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center gap-4 py-8"
                >
                  <div className="flex gap-2 h-8">
                    {[1, 2, 3, 4, 5, 6].map(i => (
                      <motion.div
                        key={i}
                        animate={{ height: [8, 32, 8] }}
                        transition={{ repeat: Infinity, duration: 0.5, delay: i * 0.1 }}
                        className="w-1.5 bg-primary rounded-full"
                      />
                    ))}
                  </div>
                  <span className="text-primary font-black italic uppercase tracking-widest">جاري الاستماع...</span>
                </motion.div>
              )}

              <div className="flex flex-wrap items-center justify-center gap-4 text-zinc-500 text-sm">
                <span className="font-bold">مقترحات:</span>
                {['قيامة عثمان', 'المتوحش', 'طائر الرفراف', 'صلاح الدين'].map(tag => (
                  <button 
                    key={tag}
                    onClick={() => { setSearchQuery(tag); handleSearch(); }}
                    className="px-4 py-2 bg-white/5 rounded-full hover:bg-white/10 hover:text-white transition-all border border-white/5"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
