import React, { useState, useEffect, useRef } from 'react';
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { ref, push, set, onValue, remove, get, Database } from 'firebase/database';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Users, Sparkles, Smile, Clock, User2, RefreshCw, Mic, Square, Volume2, Wand2, X, MessageSquare, Share2, Camera, Reply, ArrowLeft } from 'lucide-react';
import { cn } from '../lib/utils';
import { decryptValue } from '../lib/security';

let db: Database | null = null;

// Speech-to-Text types
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface ChatMessage {
  id: string;
  userName: string;
  userAvatar: string; // id of avatar in AVATARS
  text?: string;
  audioUrl?: string;
  createdAt: number;
  replyTo?: {
    userName: string;
    text: string;
  };
  sceneTime?: number;
  sceneImage?: string;
  edited?: boolean;
}

interface PendingScene {
  time: number;
  timeStr: string;
  image: string;
}

interface SeriesChatProps {
  seriesId: string;
  seriesTitle: string;
  onClose?: () => void;
  currentPlaybackTime?: number;
  onSeekTo?: (seconds: number) => void;
  isGlobal?: boolean;
  seriesImage?: string;
}

export const AVATARS = [
  {
    id: 'boy1',
    name: 'ولد أنيق',
    gender: 'boy',
    svg: (
      <svg className="w-full h-full" viewBox="0 0 100 100" fill="none">
        <defs>
          <linearGradient id="g-boy1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#1d4ed8" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="50" r="48" fill="url(#g-boy1)" />
        <path d="M50 30 C38 30, 36 40, 36 48 C36 58, 40 68, 50 68 C60 68, 64 58, 64 48 C64 40, 62 30, 50 30 Z" fill="#ffdbac" />
        <path d="M34 42 C30 30, 36 22, 50 20 C64 22, 70 30, 66 42 C62 38, 58 35, 50 37 C42 35, 38 38, 34 42 Z" fill="#2d2d2d" />
        <path d="M42 22 C32 24, 34 36, 38 40" stroke="#2d2d2d" strokeWidth="3" strokeLinecap="round" />
        <path d="M58 22 C68 24, 66 36, 62 40" stroke="#2d2d2d" strokeWidth="3" strokeLinecap="round" />
        <circle cx="43" cy="48" r="5" stroke="#ffffff" strokeWidth="2.5" fill="#1e293b" />
        <circle cx="57" cy="48" r="5" stroke="#ffffff" strokeWidth="2.5" fill="#1e293b" />
        <line x1="48" y1="48" x2="52" y2="48" stroke="#ffffff" strokeWidth="2" />
        <path d="M46 56 Q50 60 54 56" stroke="#2d2d2d" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      </svg>
    )
  },
  {
    id: 'boy2',
    name: 'ولد رياضي',
    gender: 'boy',
    svg: (
      <svg className="w-full h-full" viewBox="0 0 100 100" fill="none">
        <defs>
          <linearGradient id="g-boy2" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#f97316" />
            <stop offset="100%" stopColor="#c2410c" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="50" r="48" fill="url(#g-boy2)" />
        <path d="M50 32 C39 32, 38 42, 38 49 C38 59, 42 67, 50 67 C58 67, 62 59, 62 49 C62 42, 61 32, 50 32 Z" fill="#f1c27d" />
        <path d="M35 44 C35 32, 42 24, 50 24 C58 24, 65 32, 65 44" fill="#ef4444" />
        <ellipse cx="50" cy="24" rx="14" ry="5" fill="#dc2626" />
        <path d="M22 40 Q35 34 45 42" stroke="#dc2626" strokeWidth="4" strokeLinecap="round" />
        <circle cx="45" cy="49" r="2.5" fill="#1e293b" />
        <circle cx="55" cy="49" r="2.5" fill="#1e293b" />
        <path d="M42 45 Q45 43 47 45" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        <path d="M53 45 Q55 43 57 45" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        <path d="M45 56 Q50 62 55 56" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" fill="none" />
      </svg>
    )
  },
  {
    id: 'girl1',
    name: 'بنت أنيقة',
    gender: 'girl',
    svg: (
      <svg className="w-full h-full" viewBox="0 0 100 100" fill="none">
        <defs>
          <linearGradient id="g-girl1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ec4899" />
            <stop offset="100%" stopColor="#be185d" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="50" r="48" fill="url(#g-girl1)" />
        <path d="M50 32 C39 32, 38 41, 38 49 C38 58, 42 66, 50 66 C58 66, 62 58, 62 49 C62 41, 61 32, 50 32 Z" fill="#ffdbac" />
        <path d="M38 32 C34 32, 30 46, 30 64 C30 74, 33 76, 35 76 C37 76, 38 66, 38 49 C38 40, 42 34, 50 34 C58 34, 62 40, 62 49 C62 66, 63 76, 65 76 C67 76, 70 74, 70 64 C70 46, 66 32, 62 32 Z" fill="#312e81" />
        <path d="M38 32 C41 26, 59 26, 62 32" fill="#312e81" stroke="#312e81" strokeWidth="2" />
        <circle cx="37" cy="52" r="3" fill="#fbbf24" />
        <circle cx="63" cy="52" r="3" fill="#fbbf24" />
        <path d="M41 47 Q44 45 47 47" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" fill="none" />
        <path d="M53 47 Q56 45 59 47" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" fill="none" />
        <circle cx="44" cy="51" r="2.5" fill="#1e293b" />
        <circle cx="56" cy="51" r="2.5" fill="#1e293b" />
        <circle cx="41" cy="55" r="2" fill="#f43f5e" opacity="0.6" />
        <circle cx="59" cy="55" r="2" fill="#f43f5e" opacity="0.6" />
        <path d="M47 57 Q50 60 53 57" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" fill="none" />
      </svg>
    )
  },
  {
    id: 'girl2',
    name: 'بنت لطيفة',
    gender: 'girl',
    svg: (
      <svg className="w-full h-full" viewBox="0 0 100 100" fill="none">
        <defs>
          <linearGradient id="g-girl2" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#a855f7" />
            <stop offset="100%" stopColor="#6b21a8" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="50" r="48" fill="url(#g-girl2)" />
        <circle cx="32" cy="28" r="11" fill="#4c1d95" />
        <circle cx="68" cy="28" r="11" fill="#4c1d95" />
        <path d="M50 33 C40 33, 39 42, 39 49 C39 58, 43 66, 50 66 C57 66, 61 58, 61 49 C61 42, 60 33, 50 33 Z" fill="#f1c27d" />
        <path d="M35 38 C35 32, 40 28, 50 28 C60 28, 65 32, 65 38 C60 36, 56 34, 50 36 C44 34, 40 36, 35 38 Z" fill="#4c1d95" />
        <path d="M41 48 Q44 49 46 47" stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        <circle cx="55" cy="48" r="2.5" fill="#1e293b" />
        <path d="M47 56 Q50 61 53 56" fill="#f43f5e" />
        <path d="M47 56 Q50 61 53 56" stroke="#1e293b" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        <ellipse cx="41" cy="54" rx="3" ry="1.5" fill="#f43f5e" opacity="0.6" />
        <ellipse cx="59" cy="54" rx="3" ry="1.5" fill="#f43f5e" opacity="0.6" />
      </svg>
    )
  }
];

export default function SeriesChat({ seriesId, seriesTitle, onClose, currentPlaybackTime, onSeekTo, isGlobal, seriesImage }: SeriesChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [dbError, setDbError] = useState<string>('');
  const [isDbReady, setIsDbReady] = useState(false);
  
  // Pending scene share
  const [pendingScene, setPendingScene] = useState<PendingScene | null>(null);

  // Editing state
  const [editingMsg, setEditingMsg] = useState<ChatMessage | null>(null);
  const [selectedMsgId, setSelectedMsgId] = useState<string | null>(null);
  
  // User profile state
  const [userName, setUserName] = useState<string>('');
  const [userAvatar, setUserAvatar] = useState<string>('');
  const [isRegistered, setIsRegistered] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // Initialize DB Securely
  useEffect(() => {
    async function initSecureDB() {
      if (db) {
        setIsDbReady(true);
        return;
      }
      try {
        const res = await fetch('/api/v1/config/firebase');
        const { data } = await res.json();
        
        // Decrypt the config
        const config = Object.fromEntries(
          Object.entries(data).map(([key, val]) => [key, decryptValue(val as string)])
        );

        if (!getApps().find(a => a.name === 'chatApp')) {
          const app = initializeApp(config, 'chatApp');
          db = getDatabase(app);
        } else {
          db = getDatabase(getApp('chatApp'));
        }
        setIsDbReady(true);
      } catch (err) {
        setDbError("فشل في تهيئة نظام الدردشة الآمن.");
      }
    }
    initSecureDB();
  }, []);

  // SignUp Form status
  const [signupName, setSignupName] = useState('');
  const [signupAvatar, setSignupAvatar] = useState('boy1');
  const [signupError, setSignupError] = useState('');

  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [interimText, setInterimText] = useState('');
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const recognitionRef = useRef<any>(null);
  const preRecordingText = useRef('');
  const isIntentionalStop = useRef(false);
  const timerRef = useRef<number | null>(null);

  const [isSharing, setIsSharing] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Load User profile from LocalStorage on mount
  useEffect(() => {
    const savedName = localStorage.getItem('mo_play_user_name');
    const savedAvatar = localStorage.getItem('mo_play_user_avatar') || 'boy1';
    if (savedName) {
      setUserName(savedName);
      setUserAvatar(savedAvatar);
      setIsRegistered(true);
      setSignupName(savedName);
      setSignupAvatar(savedAvatar);
    }
  }, []);

  // Sync Timer for messages aging and active DB purge
  useEffect(() => {
    const safeSeriesId = (seriesId || 'default').replace(/[\.\$\#\[\]\/\s]/g, '_');
    
    // Purge old docs on load
    purgeExpiredDocs(safeSeriesId);

    // Active DB cleanup interval every 30 seconds to strictly remove messages from Firebase
    const timer = setInterval(() => {
      setCurrentTime(Date.now());
      purgeExpiredDocs(safeSeriesId);
    }, 30000); // Check every 30 seconds for quick & precise pruning
    return () => clearInterval(timer);
  }, [seriesId]);

  // Firebase Live Sync & Cleanup
  useEffect(() => {
    if (!isDbReady || !db) return;
    const safeSeriesId = (seriesId || 'default').replace(/[\.\$\#\[\]\/\s]/g, '_');
    const messagesRef = ref(db, `chats/${safeSeriesId}`);
    
    // Subscribe to real-time events on database
    const unsubscribe = onValue(messagesRef, (snapshot) => {
      const data = snapshot.val();
      if (!data) {
        setMessages([]);
        return;
      }

      const now = Date.now();
      const loadedMessages: ChatMessage[] = [];

      Object.entries(data).forEach(([key, val]: [string, any]) => {
        const timestamp = val.createdAt || now;
        // Client-side visual filter: only show if newer than 5 minutes
        if (now - timestamp <= 5 * 60 * 1000) {
          loadedMessages.push({
            id: key,
            userName: val.userName || 'مشاهد غامض',
            userAvatar: val.userAvatar || 'boy1',
            text: val.text || '',
            createdAt: timestamp,
            replyTo: val.replyTo,
            sceneTime: val.sceneTime,
            sceneImage: val.sceneImage
          });
        }
      });

      // Sort messages chronologically
      loadedMessages.sort((a, b) => a.createdAt - b.createdAt);
      setMessages(loadedMessages);
      setDbError(''); // Clear error if reading is successful
    }, (error) => {
      console.error("Firebase Read Error:", error);
      setDbError("عذراً، جاري انتسابك مع قواعد فايربيس. يرجى التأكد من تفعيل صلاحيات الكتابة والقراءة (Rules: .read=true, .write=true) في لوحة Firebase Realtime Database.");
    });

    return () => {
      unsubscribe();
    };
  }, [seriesId, isDbReady]);

  // Scroll to bottom on new messages
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isRegistered]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = signupName.trim();
    if (!cleanName) {
      setSignupError('يرجى كتابة اسمك المستعار');
      return;
    }
    if (cleanName.length > 15) {
      setSignupError('الاسم طويل جداً (الحد الأقصى 15 حرفاً)');
      return;
    }

    localStorage.setItem('mo_play_user_name', cleanName);
    localStorage.setItem('mo_play_user_avatar', signupAvatar);
    
    setUserName(cleanName);
    setUserAvatar(signupAvatar);
    setIsRegistered(true);
    setIsEditingProfile(false);
    setSignupError('');
  };

  const purgeExpiredDocs = async (safeId: string) => {
    if (!db) return;
    try {
      const messagesRef = ref(db, `chats/${safeId}`);
      const snapshot = await get(messagesRef);
      const data = snapshot.val();
      if (!data) return;

      const now = Date.now();
      const expiredKeys: string[] = [];

      Object.entries(data).forEach(([key, val]: [string, any]) => {
        const timestamp = val.createdAt || now;
        if (now - timestamp > 5 * 60 * 1000) {
          expiredKeys.push(key);
        }
      });

      if (expiredKeys.length > 0) {
        await Promise.all(expiredKeys.map(key => 
          remove(ref(db, `chats/${safeId}/${key}`))
        ));
      }
    } catch (err) {
      console.warn("Failed to purge old messages:", err);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!db) return;
    const txt = inputText.trim();
    if (!txt && !replyTo && !pendingScene) return;

    // Safety checks
    if (!userName || !userAvatar) return;

    const safeSeriesId = (seriesId || 'default').replace(/[\.\$\#\[\]\/\s]/g, '_');

    // If editing
    if (editingMsg) {
      try {
        const msgRef = ref(db, `chats/${safeSeriesId}/${editingMsg.id}`);
        await set(msgRef, {
          ...editingMsg,
          text: txt,
          edited: true
        });
        setEditingMsg(null);
        setInputText('');
        return;
      } catch (err) {
        console.error("Edit error:", err);
      }
    }

    const messagesRef = ref(db, `chats/${safeSeriesId}`);
    const newMsgRef = push(messagesRef);
    
    const msgData: any = {
      userName,
      userAvatar,
      text: txt || (pendingScene ? `شوفوا هاذ اللقطة عند الدقيقة ${pendingScene.timeStr} 🔥` : ''),
      createdAt: Date.now(),
    };

    if (replyTo) {
      msgData.replyTo = {
        userName: replyTo.userName,
        text: replyTo.text || 'رسالة صوتية'
      };
    }

    if (pendingScene) {
      msgData.sceneTime = pendingScene.time;
      msgData.sceneImage = pendingScene.image;
    }

    setInputText('');
    setReplyTo(null);
    setPendingScene(null);

    try {
      await set(newMsgRef, msgData);
      // Quietly clean up old messages in background
      purgeExpiredDocs(safeSeriesId);
    } catch (error) {
      console.error("Failed to send message to RTDB:", error);
      setDbError("فشل إرسال التعليق!");
    }
  };

  const shareScene = async () => {
    if (currentPlaybackTime === undefined || !isRegistered || !db) return;
    
    const mins = Math.floor(currentPlaybackTime / 60);
    const secs = Math.floor(currentPlaybackTime % 60);
    const timeStr = `${mins}:${secs.toString().padStart(2, '0')}`;
    
    setPendingScene({
      time: currentPlaybackTime,
      timeStr,
      image: seriesImage || ''
    });
    
    // Focus input
    const input = document.querySelector('input[type="text"]') as HTMLInputElement;
    if (input) input.focus();
  };

  const deleteMessage = async (msgId: string) => {
    if (!db) return;
    const safeSeriesId = (seriesId || 'default').replace(/[\.\$\#\[\]\/\s]/g, '_');
    try {
      await remove(ref(db, `chats/${safeSeriesId}/${msgId}`));
    } catch (err) {
      console.error("Delete error:", err);
    }
  };

  const startEdit = (msg: ChatMessage) => {
    setEditingMsg(msg);
    setInputText(msg.text || '');
    // Focus input
    const input = document.querySelector('input[type="text"]') as HTMLInputElement;
    if (input) input.focus();
  };

  const startRecording = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setDbError("متصفحك لا يدعم خاصية تحويل الصوت إلى نص.");
      return;
    }

    if (isRecording) {
      stopRecording();
      return;
    }

    try {
      isIntentionalStop.current = false;
      preRecordingText.current = inputText;
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-SA'; 
      recognition.continuous = true;
      recognition.interimResults = true;
      recognitionRef.current = recognition;

      recognition.onresult = (event: any) => {
        let sessionFinals = '';
        let interim = '';
        for (let i = 0; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            sessionFinals += transcript + ' ';
          } else {
            interim += transcript;
          }
        }
        
        const fullText = (preRecordingText.current + ' ' + sessionFinals).trim();
        setInputText(fullText);
        setInterimText(interim);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech Recognition Error:", event.error);
        if (event.error === 'not-allowed') {
          setDbError("يرجى السماح بالوصول للميكروفون.");
          stopRecording();
        } else if (event.error === 'network') {
          // Retry on network issues if not intentional
          if (!isIntentionalStop.current) {
            setTimeout(() => {
              if (isRecording) recognition.start();
            }, 1000);
          }
        }
      };

      recognition.onend = () => {
        // Professional Auto-Restart: If it disconnects due to silence but we haven't stopped it
        if (!isIntentionalStop.current && isRecording) {
          try {
            recognition.start();
          } catch (e) {
            console.warn("Auto-restart failed:", e);
          }
        } else if (isIntentionalStop.current) {
          setIsRecording(false);
          setInterimText('');
          if (timerRef.current) clearInterval(timerRef.current);
        }
      };

      recognition.start();
      setIsRecording(true);
      setRecordingSeconds(0);
      setInterimText('');
      
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = window.setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Speech STT error:", err);
      setDbError("حدث خطأ في تشغيل النظام الصوتي.");
    }
  };

  const stopRecording = () => {
    isIntentionalStop.current = true;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        console.error("Stop error:", e);
      }
    }
    setIsRecording(false);
    setInterimText('');
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const POPULAR_EXPRESSIONS = [
    { emoji: '🔥', label: 'حماس' },
    { emoji: '👑', label: 'أسطوري' },
    { emoji: '😱', label: 'صدمة' },
    { emoji: '🤣', label: 'هههه' },
    { emoji: '❤️', label: 'بطل' },
    { emoji: '👋', label: 'يا هلا' }
  ];

  const sendExpression = async (exprText: string) => {
    if (!isRegistered || !userName || !userAvatar || !db) return;
    try {
      const safeSeriesId = (seriesId || 'default').replace(/[\.\$\#\[\]\/\s]/g, '_');
      const messagesRef = ref(db, `chats/${safeSeriesId}`);
      const newMsgRef = push(messagesRef);
      await set(newMsgRef, {
        userName,
        userAvatar,
        text: exprText,
        createdAt: Date.now()
      });

      // Quietly clean up old messages in background
      purgeExpiredDocs(safeSeriesId);
    } catch (error) {
      console.warn("RTDB expression shoot error:", error);
      setDbError("فشل إرسال التفاعل السريع! يرجى مراجعة صلاحيات وقواعد الكتابة لـ Realtime Database.");
    }
  };

  const handleLogOut = () => {
    localStorage.removeItem('mo_play_user_name');
    localStorage.removeItem('mo_play_user_avatar');
    setIsRegistered(false);
    setUserName('');
    setUserAvatar('');
  };

  // Helper to format remaining time until message is deleted (5 mins lifespan)
  const getRemainingTimeText = (createdAt: number) => {
    const elapsed = currentTime - createdAt;
    const remainingMs = 5 * 60 * 1000 - elapsed;
    if (remainingMs <= 0) return 'يختفي الآن...';
    
    const remainingSecs = Math.floor(remainingMs / 1000);
    const mins = Math.floor(remainingSecs / 60);
    const secs = remainingSecs % 60;
    
    return `يختفي خلال ${mins}:${secs.toString().padStart(2, '0')} د`;
  };

  const selectedAvatarObj = AVATARS.find(a => a.id === userAvatar);

  return (
    <div className="w-full bg-[#0d0d12] rounded-3xl border border-white/5 overflow-hidden flex flex-col h-full shadow-[0_20px_50px_rgba(0,0,0,0.8)] relative font-sans">
      {/* Header */}
      <div className="bg-[#121218] border-b border-white/5 p-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          {onClose && (
            <button 
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-zinc-400 hover:text-white transition-all ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          {isRegistered && (
            <div className="flex items-center gap-2 mr-2">
              <button 
                onClick={() => setIsEditingProfile(true)}
                className="text-[10px] text-zinc-500 hover:text-primary transition-colors p-1.5 hover:bg-white/5 rounded-lg border border-white/5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <div className="text-right">
                <span className="text-xs font-black text-zinc-300 block leading-tight">{userName}</span>
                <span className="text-[8px] text-emerald-400 font-bold">متصل</span>
              </div>
              <div className="w-8.5 h-8.5 rounded-full border border-white/10 bg-zinc-900 overflow-hidden shrink-0 shadow-md">
                {selectedAvatarObj?.svg}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <h3 className="text-xs sm:text-sm font-black text-white flex items-center gap-1.5 justify-end">مجلس المتابعين</h3>
            <p className="text-[10px] text-zinc-400 font-bold flex items-center gap-1 mt-0.5 justify-end uppercase tracking-wider">
              <span>يختفي بعد ٥ دق</span>
              <Clock className="w-3 h-3 text-primary shrink-0" />
            </p>
          </div>
          <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center border border-primary/20 text-primary shrink-0">
            <MessageSquare className="w-5.5 h-5.5" />
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 relative overflow-hidden flex flex-col bg-zinc-950">
        
        {/* Profile Dialog */}
        <AnimatePresence>
          {(!isRegistered || isEditingProfile) && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/95 backdrop-blur-md z-20 flex flex-col items-center justify-center p-6 text-right"
            >
              <form onSubmit={handleRegister} className="w-full max-w-sm space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-14 h-14 bg-primary/20 rounded-2xl flex items-center justify-center border border-primary/20 mx-auto text-primary">
                    <Sparkles className="w-7 h-7 animate-pulse" />
                  </div>
                  <h4 className="text-lg font-black text-white">{isEditingProfile ? 'تعديل الملف الشخصي' : 'مجلس المتابعين المباشر'}</h4>
                  <p className="text-xs text-zinc-400">{isEditingProfile ? 'حدث بياناتك للتعرف عليك' : 'اختر اسماً وصورة للدردشة مع المتابعين!'}</p>
                </div>

                <div className="space-y-4 text-right">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase text-zinc-500 block pr-1">الاسم المستعار</label>
                    <input 
                      type="text" 
                      dir="rtl"
                      value={signupName}
                      onChange={(e) => setSignupName(e.target.value)}
                      className="w-full px-4 py-3 bg-white/5 border border-white/5 rounded-2xl text-white text-xs focus:ring-1 focus:ring-primary/40 outline-none text-right"
                    />
                  </div>
                  <div className="grid grid-cols-4 gap-2.5">
                    {AVATARS.map((av) => (
                      <button
                        key={av.id}
                        type="button"
                        onClick={() => setSignupAvatar(av.id)}
                        className={`relative aspect-square rounded-2xl p-1 bg-zinc-900 border transition-all ${signupAvatar === av.id ? 'border-primary ring-2 ring-primary/30 scale-105' : 'border-white/5'}`}
                      >
                        {av.svg}
                        {signupAvatar === av.id && (
                          <div className="absolute -bottom-1 -right-1 bg-primary text-white text-[9px] w-4 h-4 rounded-full font-black flex items-center justify-center shadow">✓</div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2">
                  {isEditingProfile && (
                    <button type="button" onClick={() => setIsEditingProfile(false)} className="w-1/3 py-3.5 bg-white/5 text-zinc-400 rounded-full font-black text-xs">إلغاء</button>
                  )}
                  <button type="submit" className="flex-1 py-3.5 bg-primary text-white rounded-full font-black text-xs shadow-lg shadow-primary/20">
                    {isEditingProfile ? 'حفظ التعديلات' : 'دخول الدردشة'}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Message List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar relative">
          {messages.map((msg) => {
            const msgAvatarObj = AVATARS.find(a => a.id === msg.userAvatar);
            const isMe = msg.userName === userName;
            return (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex items-start gap-2.5 ${isMe ? 'flex-row-reverse text-right' : 'flex-row text-right'}`}
              >
                <div className="w-8 h-8 rounded-full bg-zinc-900 border border-white/5 shrink-0 overflow-hidden shadow">
                  {msgAvatarObj?.svg}
                </div>
                <div className={`flex flex-col max-w-[75%] ${isMe ? 'items-end' : 'items-start'}`}>
                  <div className="flex items-center gap-1.5 mb-1 text-[9px] font-black text-zinc-500">
                    <span>{msg.userName}</span>
                    <span className="text-[8px] font-mono opacity-60 tracking-wider pr-1.5 border-r border-white/10">{getRemainingTimeText(msg.createdAt)}</span>
                  </div>
                  <div 
                    className={cn(
                      "group relative px-3.5 py-2 rounded-2xl text-[12px] font-semibold leading-relaxed shadow-lg cursor-pointer transition-all",
                      isMe ? "bg-primary text-black rounded-tr-none" : "bg-zinc-900 border border-white/5 text-zinc-100 rounded-tl-none",
                      selectedMsgId === msg.id && "ring-2 ring-white/20 scale-[0.98]"
                    )}
                    onClick={() => setSelectedMsgId(selectedMsgId === msg.id ? null : msg.id)}
                  >
                    {msg.replyTo && (
                      <div className={cn(
                        "mb-2 p-2 rounded-xl border-r-2 text-[10px] opacity-70 italic",
                        isMe ? "bg-black/10 border-black/20" : "bg-black/20 border-white/20 text-zinc-300"
                      )}>
                        <span className="font-black block mb-0.5">{msg.replyTo.userName}</span>
                        {msg.replyTo.text}
                      </div>
                    )}
                    {msg.text}
                    {msg.edited && <span className="text-[8px] opacity-50 mr-1">(تم التعديل)</span>}
                    {msg.sceneTime !== undefined && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); onSeekTo?.(msg.sceneTime!); }} 
                        className={cn(
                          "mt-3 block w-full overflow-hidden rounded-xl border transition-all group/card",
                          isMe ? "bg-black/10 border-black/10" : "bg-black/40 border-white/10 hover:bg-black/60"
                        )}
                      >
                        <div className="relative aspect-video w-full bg-zinc-800 flex items-center justify-center overflow-hidden">
                          {msg.sceneImage ? (
                            <img src={msg.sceneImage} referrerPolicy="no-referrer" alt="scene" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover/card:scale-110 transition-transform" />
                          ) : (
                            <div className="absolute inset-0 flex items-center justify-center opacity-40 group-hover/card:scale-110 transition-transform">
                              <MessageSquare className="w-12 h-12" />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10" />
                          <div className={cn(
                            "absolute bottom-2 right-2 z-20 flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-black italic",
                            isMe ? "bg-black text-white" : "bg-primary text-black"
                          )}>
                            <Clock className="w-3 h-3" />
                            <span>{Math.floor(msg.sceneTime / 60)}:{(msg.sceneTime % 60).toString().padStart(2, '0')}</span>
                          </div>
                        </div>
                        <div className="p-2.5 text-right">
                          <p className={cn("text-[10px] font-bold", isMe ? "text-black/60" : "text-zinc-300")}>اضغط لمشاهدة اللقطة...</p>
                        </div>
                      </button>
                    )}

                    {/* Quick Menu Overlay */}
                    <AnimatePresence>
                      {selectedMsgId === msg.id && (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.8, y: 10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.8, y: 10 }}
                          className={cn(
                            "absolute z-50 flex items-center gap-1 bg-[#1a1a23] border border-white/10 p-1.5 rounded-2xl shadow-2xl top-full mt-2",
                            isMe ? "right-0" : "left-0"
                          )}
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button onClick={() => { setReplyTo(msg); setSelectedMsgId(null); }} className="p-2 hover:bg-white/5 rounded-xl text-zinc-400 hover:text-primary transition-colors flex items-center gap-2 px-3">
                            <Reply className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-black">رد</span>
                          </button>
                          {isMe && (
                            <>
                              <div className="w-[1px] h-4 bg-white/10" />
                              <button onClick={() => { startEdit(msg); setSelectedMsgId(null); }} className="p-2 hover:bg-white/5 rounded-xl text-zinc-400 hover:text-blue-400 transition-colors flex items-center gap-2 px-3">
                                <Wand2 className="w-3.5 h-3.5" />
                                <span className="text-[10px] font-black">تعديل</span>
                              </button>
                              <div className="w-[1px] h-4 bg-white/10" />
                              <button onClick={() => { deleteMessage(msg.id); setSelectedMsgId(null); }} className="p-2 hover:bg-white/5 rounded-xl text-zinc-400 hover:text-rose-500 transition-colors flex items-center gap-2 px-3">
                                <X className="w-3.5 h-3.5" />
                                <span className="text-[10px] font-black">حذف</span>
                              </button>
                            </>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </motion.div>
            );
          })}
          <div ref={chatEndRef} />
        </div>

        {/* Input area */}
        <div className="bg-[#121218] border-t border-white/5">
          <AnimatePresence mode="popLayout">
            {replyTo && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="px-4 py-2 bg-white/5 flex items-center justify-between border-b border-white/5"
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <Reply className="w-3 h-3 text-primary shrink-0" />
                  <div className="text-[10px] text-zinc-400 truncate pr-2">
                    <span className="font-black text-white/50">رد على {replyTo.userName}:</span> {replyTo.text}
                  </div>
                </div>
                <button onClick={() => setReplyTo(null)} className="text-zinc-500 hover:text-white"><X className="w-4 h-4" /></button>
              </motion.div>
            )}

            {editingMsg && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="px-4 py-2 bg-blue-500/10 flex items-center justify-between border-b border-blue-500/20"
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <Wand2 className="w-3 h-3 text-blue-400 shrink-0" />
                  <div className="text-[10px] text-blue-400/70 truncate pr-2">
                    <span className="font-black">تعديل رسالتك:</span> {editingMsg.text}
                  </div>
                </div>
                <button onClick={() => { setEditingMsg(null); setInputText(''); }} className="text-zinc-500 hover:text-white"><X className="w-4 h-4" /></button>
              </motion.div>
            )}

            {pendingScene && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-3 bg-zinc-900 border-b border-emerald-500/20"
              >
                <div className="flex items-center gap-3">
                  <div className="w-20 aspect-video rounded-lg overflow-hidden bg-black shrink-0 border border-white/10 relative">
                    {pendingScene.image && <img src={pendingScene.image} referrerPolicy="no-referrer" className="w-full h-full object-cover opacity-50" />}
                    <Camera className="absolute inset-0 m-auto w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-[10px] font-black text-emerald-400">مشاركة لقطة</p>
                    <p className="text-[9px] text-zinc-500">سيتم إرفاق لقطة عند {pendingScene.timeStr}</p>
                  </div>
                  <button onClick={() => setPendingScene(null)} className="p-2 hover:bg-white/5 rounded-full text-zinc-500"><X className="w-4 h-4" /></button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {isRegistered && !isGlobal && (
            <div className="px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <button 
                onClick={shareScene} 
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black transition-all shrink-0 border",
                  pendingScene 
                    ? "bg-zinc-800 text-zinc-500 border-white/5 cursor-not-allowed" 
                    : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20"
                )}
              >
                <Camera className="w-3.5 h-3.5" /> 
                {pendingScene ? 'جاري التحضير...' : 'شاركنا لقطة'}
              </button>
              {['🔥 حماس', '😍 أسطوري', '😭 حزن'].map(e => (
                <button key={e} onClick={() => { setInputText(e); setTimeout(() => handleSendMessage(), 50); }} className="px-3 py-1 bg-zinc-900 rounded-full text-[10px] text-zinc-400 border border-white/5 hover:border-zinc-700 transition-all shrink-0 hover:text-white">{e}</button>
              ))}
            </div>
          )}

          <form onSubmit={handleSendMessage} className="p-3 flex gap-2 items-center">
            {isRecording ? (
              <div className="flex-1 flex items-center justify-between bg-primary/10 border border-primary/20 rounded-2xl px-4 py-2">
                <div className="flex items-center gap-3">
                  <Wand2 className="w-4 h-4 text-primary animate-pulse" />
                  <div className="text-[10px] font-black text-primary uppercase tracking-widest truncate max-w-[150px]">أسمعك... {interimText}</div>
                </div>
                <button type="button" onClick={stopRecording} className="w-7 h-7 bg-primary text-white rounded-full flex items-center justify-center shadow-lg"><Square className="w-3 h-3" /></button>
              </div>
            ) : (
              <>
                <button type="submit" disabled={!inputText.trim() && !replyTo && !pendingScene} className={cn("w-10 h-10 rounded-full flex items-center justify-center shadow-lg shrink-0 transition-all", (inputText.trim() || replyTo || pendingScene) ? "bg-primary text-black" : "bg-white/5 text-zinc-500 opacity-20")}><Send className={cn("w-4.5 h-4.5 -rotate-45", editingMsg && "rotate-0")} /></button>
                <input type="text" dir="rtl" value={inputText} onChange={(e) => setInputText(e.target.value)} disabled={!isRegistered} placeholder={pendingScene ? "اكتب تعليقك على اللقطة..." : editingMsg ? "اكتب التعديل..." : isRegistered ? "اكتب تعليقك هنا..." : "انضم للمجلس..."} className="flex-1 bg-white/5 border border-white/5 rounded-full py-2.5 px-5 text-xs outline-none text-white focus:ring-1 focus:ring-primary/40 placeholder-zinc-600 font-semibold" />
                {isRegistered && <button type="button" onClick={startRecording} className="w-10 h-10 bg-zinc-800 text-zinc-400 rounded-full flex items-center justify-center hover:text-white shrink-0 transition-colors"><Mic className="w-4.5 h-4.5" /></button>}
              </>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
