import React from 'react';
import { cn } from '../lib/utils';
import { Episode } from '../services/firebase';
import { CheckCircle2 } from 'lucide-react';
import { progressService } from '../services/progressService';

interface EpisodeGridProps {
  episodes: Episode[];
  currentIndex: number;
  seriesId: string;
  onSelect: (ep: Episode, index: number) => void;
}

export default function EpisodeGrid({ episodes, currentIndex, seriesId, onSelect }: EpisodeGridProps) {
  return (
    <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2 sm:gap-3 px-0 sm:px-4">
      {episodes.map((ep, index) => {
        const isWatched = progressService.isWatched(seriesId, index);
        
        return (
          <button
            key={index}
            onClick={() => onSelect(ep, index)}
            className={cn(
              "aspect-square rounded-lg font-bold transition-all flex flex-col items-center justify-center text-sm sm:text-lg border relative",
              currentIndex === index
                ? "bg-primary border-primary text-white scale-105 shadow-lg shadow-primary/30"
                : "bg-white/5 border-white/10 text-gray-400 hover:bg-white/10 hover:text-white"
            )}
          >
            {isWatched && (
              <CheckCircle2 className="w-3 h-3 text-green-400 absolute top-1 right-1" />
            )}
            {ep.title || (index + 1)}
          </button>
        );
      })}
    </div>
  );
}
