import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import Hls from 'hls.js';
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, 
  RotateCcw, RotateCw, List, Settings, CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { Episode } from '../services/firebase';
import { progressService } from '../services/progressService';
import HorizontalEpisodeList from './HorizontalEpisodeList';

interface CustomPlayerProps {
  videoUrl: string;
  seriesId: string;
  seriesImage: string;
  episodeIndex: number;
  episodes: Episode[];
  servers: { name: string; url: string }[];
  onSelectEpisode: (ep: Episode, index: number) => void;
  onSelectServer: (url: string) => void;
  isMaximized: boolean;
  onToggleMaximize: () => void;
  onTimeUpdate?: (time: number) => void;
}

const CustomPlayer = forwardRef((props: CustomPlayerProps, ref) => {
  const {
    videoUrl,
    seriesId,
    seriesImage,
    episodeIndex,
    episodes,
    servers,
    onSelectEpisode,
    onSelectServer,
    isMaximized,
    onToggleMaximize,
    onTimeUpdate,
  } = props;

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useImperativeHandle(ref, () => ({
    seekTo: (seconds: number) => {
      if (videoRef.current) {
        videoRef.current.currentTime = seconds;
        videoRef.current.play().catch(() => {});
      }
    },
    play: () => videoRef.current?.play().catch(() => {}),
    pause: () => videoRef.current?.pause(),
  }));
  
  // Custom PlayerJS properties
  const [playerjsLoaded, setPlayerjsLoaded] = useState(false);
  const playerjsInstanceRef = useRef<any>(null);

  // Native player properties
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showControls, setShowControls] = useState(true);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showEpisodeMenu, setShowEpisodeMenu] = useState(false);
  const [isIframeFallback, setIsIframeFallback] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [showRewindAnimation, setShowRewindAnimation] = useState(false);
  const [showForwardAnimation, setShowForwardAnimation] = useState(false);
  const [isHoveringControls, setIsHoveringControls] = useState(false);

  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastTapRef = useRef<{ time: number; side: 'left' | 'right' | 'middle' | null }>({ time: 0, side: null });
  const clickTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastTouchTimeRef = useRef<number>(0);

  // Dynamic PlayerJS Loader
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Detect if already loaded globally (i.e. if playerjsCode.js or a direct upload exists)
    if ((window as any).Playerjs) {
      setPlayerjsLoaded(true);
      return;
    }

    // Try to load custom playerjs.js from the public directory
    const script = document.createElement('script');
    script.src = '/playerjs.js';
    script.async = true;
    script.onload = () => {
      if ((window as any).Playerjs) {
        console.log('PlayerJS custom copy loaded successfully from /public/playerjs.js');
        setPlayerjsLoaded(true);
      }
    };
    script.onerror = () => {
      console.log('Custom playerjs.js not found in public folder. Using sleek fallback native player.');
    };
    document.body.appendChild(script);

    return () => {
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  // Initialize PlayerJS if loaded and direct stream is used (non-embed)
  useEffect(() => {
    if (!playerjsLoaded || isIframeFallback || !videoUrl) return;

    const PlayerjsClass = (window as any).Playerjs;
    if (!PlayerjsClass) return;

    // Destroy any existing playerjs instance first
    if (playerjsInstanceRef.current) {
      try {
        playerjsInstanceRef.current?.api('destroy');
      } catch (e) {
        console.warn('Error destroying playerjs:', e);
      }
      playerjsInstanceRef.current = null;
    }

    // Prepare container
    const container = document.getElementById('pjs-player');
    if (!container) return;
    container.innerHTML = '';

    setIsLoading(false);

    try {
      const pjs = new PlayerjsClass({
        id: 'pjs-player',
        file: videoUrl,
        autoplay: true,
      });

      playerjsInstanceRef.current = pjs;
    } catch (err) {
      console.error('Error starting PlayerJS:', err);
    }

    return () => {
      if (playerjsInstanceRef.current) {
        try {
          playerjsInstanceRef.current.api('destroy');
        } catch (e) {
          console.warn('Error destroying playerjs on cleanup:', e);
        }
        playerjsInstanceRef.current = null;
      }
    };
  }, [playerjsLoaded, videoUrl, isIframeFallback]);

  // Check if link is iframe/embed only or a standard direct video
  useEffect(() => {
    setIsLoading(true);
    setIsIframeFallback(false);
    
    if (!videoUrl) {
      return;
    }
    
    const urlLower = videoUrl.toLowerCase();
    const isDirectVideo = 
      urlLower.includes('.mp4') || 
      urlLower.includes('.m3u8') || 
      urlLower.includes('.webm') || 
      urlLower.includes('.ogg') || 
      urlLower.includes('.mov') ||
      urlLower.includes('.jpg') ||
      urlLower.includes('.png');

    if (!isDirectVideo) {
      setIsIframeFallback(true);
      setIsLoading(false);
      return;
    }

    if (playerjsLoaded) {
      // If PlayerJS is active, we let it manage itself
      setIsLoading(false);
      return;
    }

    // Direct stream initialization for the fallback native player
    const video = videoRef.current;
    if (!video) return;

    let hls: Hls | null = null;

    if (urlLower.includes('.m3u8')) {
      if (Hls.isSupported()) {
        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: false,
          maxBufferLength: 45,
          maxMaxBufferLength: 90,
          maxBufferSize: 80 * 1024 * 1024,
          progressive: true,
          capLevelToPlayerSize: true,
          autoStartLoad: true,
          abrBandWidthFactor: 0.8,
          abrBandWidthUpFactor: 0.6,
          testBandwidth: true
        });
        hls.loadSource(videoUrl);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setIsLoading(false);
          resumeWatchProgress();
          video.play().catch(() => setIsPlaying(false));
          setIsPlaying(true);
        });
        hls.on(Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            console.warn("HLS fatal error, falling back to iframe", data);
            setIsIframeFallback(true);
            setIsLoading(false);
          }
        });
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = videoUrl;
        video.addEventListener('loadedmetadata', () => {
          setIsLoading(false);
          resumeWatchProgress();
          video.play().catch(() => setIsPlaying(false));
          setIsPlaying(true);
        });
      } else {
        setIsIframeFallback(true);
        setIsLoading(false);
      }
    } else {
      // Regular streaming files (MP4/WebM)
      video.src = videoUrl;
      const onPlayable = () => {
        setIsLoading(false);
        resumeWatchProgress();
        video.play().catch(() => setIsPlaying(false));
        setIsPlaying(true);
        video.removeEventListener('canplay', onPlayable);
      };
      video.addEventListener('canplay', onPlayable);
    }

    return () => {
      if (hls) {
        hls.destroy();
      }
      if (video) {
        video.pause();
        video.src = '';
      }
    };
  }, [videoUrl, episodeIndex, playerjsLoaded]);

  // Resume progress logic
  const resumeWatchProgress = () => {
    const video = videoRef.current;
    if (!video) return;
    const savedSecond = progressService.getProgress(seriesId, episodeIndex);
    if (savedSecond > 0 && savedSecond < (video.duration || 100000)) {
      video.currentTime = savedSecond;
    }
  };

  // Auto-Save watch progress every 4 seconds
  useEffect(() => {
    if (isIframeFallback || playerjsLoaded) return;
    const interval = setInterval(() => {
      const video = videoRef.current;
      if (video && isPlaying && video.currentTime > 5) {
        progressService.saveProgress(seriesId, episodeIndex, video.currentTime);
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [isPlaying, isIframeFallback, seriesId, episodeIndex, playerjsLoaded]);

  // Mouse activity timer to hide controls automatically - upgraded to a comfortable and generous 10 seconds timeout
  const resetControlsTimeout = (forceShow: boolean = true) => {
    if (!isPlaying) {
      setShowControls(false);
      return;
    }
    if (forceShow) {
      setShowControls(true);
    }
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }

    // If the user is currently hovering/focused on controls, NEVER hide them!
    if (isHoveringControls) {
      return;
    }

    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying && !showSpeedMenu && !showEpisodeMenu && !isHoveringControls) {
        setShowControls(false);
      }
    }, 2500); // Highly comfortable 2.5 seconds auto-hide timeout
  };

  // Toggle controls visibility and handle timeouts properly
  const toggleControls = () => {
    if (!isPlaying) {
      setShowControls(false);
      return;
    }
    setShowControls(prev => {
      const next = !prev;
      if (next) {
        if (controlsTimeoutRef.current) {
          clearTimeout(controlsTimeoutRef.current);
        }
        if (isPlaying && !isHoveringControls) {
          controlsTimeoutRef.current = setTimeout(() => {
            if (videoRef.current && !videoRef.current.paused && !showSpeedMenu && !showEpisodeMenu && !isHoveringControls) {
              setShowControls(false);
            }
          }, 2500);
        }
      } else {
        if (controlsTimeoutRef.current) {
          clearTimeout(controlsTimeoutRef.current);
          controlsTimeoutRef.current = null;
        }
      }
      return next;
    });
  };

  useEffect(() => {
    resetControlsTimeout();
    return () => {
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
      if (clickTimeoutRef.current) clearTimeout(clickTimeoutRef.current);
    };
  }, [isPlaying, showSpeedMenu, showEpisodeMenu, isHoveringControls]);

  // Handle Play/Pause Action
  const handlePlayPause = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
      setShowControls(false); // Hide controls when paused as requested
    } else {
      video.play().catch(() => {});
      setIsPlaying(true);
      setShowControls(true); // Show when resumed
      resetControlsTimeout(); // Hide controls after comfortable timeout
    }
  };

  // Core gesture state machine
  const handleInteraction = (clientX: number, currentTarget: HTMLElement) => {
    const video = videoRef.current;
    if (!video) return;

    const rect = currentTarget.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const width = rect.width;
    const clickPercent = clickX / width;
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 280;

    let zone: 'left' | 'right' | 'middle' = 'middle';
    if (clickPercent < 0.35) {
      zone = 'left';
    } else if (clickPercent > 0.65) {
      zone = 'right';
    }

    const isDoubleTap = (zone === 'left' || zone === 'right') &&
                        (zone === lastTapRef.current.side) &&
                        (now - lastTapRef.current.time < DOUBLE_TAP_DELAY);

    lastTapRef.current = { time: now, side: zone };

    if (isDoubleTap) {
      if (clickTimeoutRef.current) {
        clearTimeout(clickTimeoutRef.current);
        clickTimeoutRef.current = null;
      }

      if (zone === 'left') {
        skipTime(-10);
      } else {
        skipTime(10);
      }
      return;
    }

    if (clickTimeoutRef.current) {
      clearTimeout(clickTimeoutRef.current);
      clickTimeoutRef.current = null;
    }

    const executeSingleClick = () => {
      setShowSpeedMenu(false);
      setShowEpisodeMenu(false);

      if (zone === 'middle') {
        if (isPlaying) {
          video.pause();
          setIsPlaying(false);
          setShowControls(false); // Hide controls when paused as requested
        } else {
          video.play().catch(() => {});
          setIsPlaying(true);
          setShowControls(true); // Show when resumed
          resetControlsTimeout();
        }
      } else {
        // Simple click in left/right zones ONLY triggers toggles if currently playing
        if (isPlaying) {
          toggleControls();
        }
      }
    };

    if (zone === 'middle') {
      executeSingleClick();
    } else {
      clickTimeoutRef.current = setTimeout(() => {
        executeSingleClick();
        clickTimeoutRef.current = null;
      }, DOUBLE_TAP_DELAY);
    }
  };

  const handlePlayerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();

    if (Date.now() - lastTouchTimeRef.current < 600) {
      return;
    }

    const target = e.target as HTMLElement;
    if (
      target.closest('button') || 
      target.closest('input') || 
      target.closest('a') ||
      target.closest('.custom-scrollbar') ||
      target.closest('.no-toggle')
    ) {
      return;
    }

    handleInteraction(e.clientX, e.currentTarget);
  };

  const handlePlayerTouch = (e: React.TouchEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    if (
      target.closest('button') || 
      target.closest('input') || 
      target.closest('a') ||
      target.closest('.custom-scrollbar') ||
      target.closest('.no-toggle')
    ) {
      return;
    }

    e.preventDefault();
    e.stopPropagation();

    lastTouchTimeRef.current = Date.now();
    const touch = e.touches[0] || e.changedTouches[0];
    if (touch) {
      handleInteraction(touch.clientX, e.currentTarget);
    }
  };

  const handleVideoError = () => {
    console.warn("Native video playback failed, falling back to iframe player.");
    setIsIframeFallback(true);
    setIsLoading(false);
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    onTimeUpdate?.(currentTime);
  }, [currentTime, onTimeUpdate]);

  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;
    setCurrentTime(video.currentTime);
  };

  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    if (!video) return;
    setDuration(video.duration);
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const video = videoRef.current;
    if (!video || isNaN(duration) || duration === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const width = rect.width;
    const clickPercent = clickX / width;
    
    video.currentTime = clickPercent * duration;
    setCurrentTime(video.currentTime);
    resetControlsTimeout();
  };

  const skipTime = (amount: number, e?: React.MouseEvent | React.TouchEvent) => {
    if (e) e.stopPropagation();
    const video = videoRef.current;
    if (!video) return;
    video.currentTime = Math.min(Math.max(0, video.currentTime + amount), duration);
    setCurrentTime(video.currentTime);
    resetControlsTimeout(showControls);

    if (amount < 0) {
      setShowRewindAnimation(true);
      setTimeout(() => setShowRewindAnimation(false), 800);
    } else {
      setShowForwardAnimation(true);
      setTimeout(() => setShowForwardAnimation(false), 800);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    const video = videoRef.current;
    if (video) {
      video.volume = val;
      video.muted = val === 0;
      setVolume(val);
      setIsMuted(val === 0);
    }
    resetControlsTimeout();
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const video = videoRef.current;
    if (video) {
      video.muted = !isMuted;
      setIsMuted(!isMuted);
    }
    resetControlsTimeout();
  };

  const handleSpeedChange = (rate: number) => {
    const video = videoRef.current;
    if (video) {
      video.playbackRate = rate;
      setPlaybackRate(rate);
    }
    setShowSpeedMenu(false);
    resetControlsTimeout();
  };

  const toggleBrowserFullscreen = () => {
    const container = containerRef.current;
    const video = videoRef.current;

    if (!container) return;

    // Check if any element is already in fullscreen
    const isFullscreen = document.fullscreenElement || (document as any).webkitFullscreenElement;

    if (isFullscreen) {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if ((document as any).webkitExitFullscreen) {
        (document as any).webkitExitFullscreen();
      }
    } else {
      const isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent);
      
      if (isIOS) {
        // iOS: Force CSS-based maximize to keep our UI overlays visible
        onToggleMaximize();
      } else {
        // Desktop/Other: Use native Fullscreen
        if (container.requestFullscreen) {
          container.requestFullscreen().catch(() => onToggleMaximize());
        } else if ((container as any).webkitRequestFullscreen) {
          (container as any).webkitRequestFullscreen();
        } else if (video && (video as any).webkitEnterFullscreen) {
          (video as any).webkitEnterFullscreen();
        } else {
          onToggleMaximize();
        }
      }
    }
  };

  return (
    <div 
      ref={containerRef}
      onMouseMove={() => resetControlsTimeout(false)}
      onMouseLeave={() => isPlaying && !isHoveringControls && setShowControls(false)}
      onClick={handlePlayerClick}
      className={cn(
        "relative select-none flex flex-col items-center justify-center bg-black overflow-hidden group w-full h-full text-white cursor-pointer",
        isMaximized ? "fixed inset-0 w-screen h-screen z-[200]" : "aspect-video rounded-xl border border-white/5"
      )}
    >
      {!videoUrl ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/95 gap-4">
          <div className="w-14 h-14 border-4 border-primary border-t-transparent rounded-full animate-spin shadow-lg shadow-primary/20" />
          <p className="text-zinc-400 text-sm font-bold tracking-widest text-center px-4">جاري تجهيز سيرفرات المشغل المباشر...</p>
        </div>
      ) : isIframeFallback ? (
        // Iframe / Web Embed Player view
        <div className="relative w-full h-full flex items-center justify-center bg-zinc-950">
          <iframe 
            src={videoUrl}
            className="w-full h-full border-none"
            allowFullScreen
            allow="autoplay; encrypted-media"
            title="External Movie Player"
          />
          
          <div className="absolute top-4 right-4 z-40 flex items-center gap-2">
            <button
              onClick={() => setShowEpisodeMenu(!showEpisodeMenu)}
              className="flex items-center gap-2 bg-black/80 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10 hover:bg-black text-white hover:text-primary transition-all text-[10px] font-black uppercase tracking-wider shadow-2xl"
            >
              <List className="w-4 h-4 text-primary" />
              اختيار حلقة
            </button>
            
            <button
              onClick={onToggleMaximize}
              className="p-2 bg-black/80 backdrop-blur-md rounded-xl border border-white/10 hover:bg-black text-white hover:text-primary transition-all shadow-2xl"
              title={isMaximized ? "تصغير الشاشة" : "تكبير الشاشة"}
            >
              {isMaximized ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
      ) : playerjsLoaded ? (
        // Dynamic custom PlayerJS renderer container
        <div className="relative w-full h-full">
          <div id="pjs-player" className="w-full h-full bg-black" />
          
          {/* Transparent bar for floating episode and maximize triggers on PlayerJS */}
          <div className="absolute top-4 right-4 z-40 flex items-center gap-2">
            <button
              onClick={(e) => { e.stopPropagation(); setShowEpisodeMenu(!showEpisodeMenu); }}
              className="flex items-center gap-2 bg-black/85 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10 hover:bg-black text-white hover:text-primary transition-all text-[10px] font-black uppercase tracking-wider shadow-2xl"
            >
              <List className="w-4 h-4 text-primary" />
              الحلقات
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onToggleMaximize(); }}
              className="p-2 bg-black/85 backdrop-blur-md rounded-xl border border-white/10 hover:bg-black text-white hover:text-primary transition-all shadow-2xl"
            >
              {isMaximized ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
      ) : (
        // High fidelity completely updated stable native fallback player (Netflix / YouTube styling)
        <>
          {isLoading && (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/90 gap-4">
              <div className="w-14 h-14 border-4 border-primary border-t-transparent rounded-full animate-spin shadow-lg shadow-primary/20" />
              <p className="text-zinc-400 text-xs font-bold tracking-widest uppercase">جاري التجهيز والتشغيل...</p>
            </div>
          )}

          <video
            ref={videoRef}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onError={handleVideoError}
            className={cn(
              "w-full h-full object-contain pointer-events-none transition-all duration-500",
              !isPlaying ? "opacity-60 blur-[2px]" : "opacity-100 blur-0"
            )}
            playsInline
            webkitPlaysInline
            controls={false}
            disablePictureInPicture={true}
            disableRemotePlayback={true}
          />

          {/* Paused Overlay Dimming Layer */}
          {!isPlaying && (
            <div className="absolute inset-0 z-20 bg-gradient-to-t from-black/60 to-transparent backdrop-blur-[2px] pointer-events-none" />
          )}

          {/* Master Video overlay gestures & controls layer */}
          <div 
            onClick={handlePlayerClick}
            onTouchStart={handlePlayerTouch}
            className="absolute inset-0 z-[100] select-none touch-none cursor-pointer flex items-center justify-center"
          >
            {/* Left side rewinding feedback animation */}
            <div className="absolute left-[10%] sm:left-[15%] pointer-events-none z-20">
              <AnimatePresence>
                {showRewindAnimation && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.4 }}
                    animate={{ opacity: 1, scale: 1.1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="flex flex-col items-center justify-center bg-black/85 text-white rounded-full w-20 h-20 border border-white/10 shadow-[0_0_30px_rgba(229,9,20,0.3)]"
                  >
                    <RotateCcw className="w-8 h-8 text-primary animate-pulse" />
                    <span className="text-[10px] font-black tracking-wider mt-1">10- ث</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Central Play indicator overlay */}
            <div className="pointer-events-none z-20">
              <div className={cn(
                "transition-all duration-300 transform",
                !isPlaying ? "opacity-100 scale-110" : "opacity-0 scale-90"
              )}>
                <div className="p-5 rounded-full bg-black/85 backdrop-blur-2xl border border-white/10 text-white shadow-[0_0_40px_rgba(229,9,20,0.65)]">
                  <div className="flex flex-col items-center justify-center gap-1">
                    <Play className="w-10 h-10 text-primary fill-current ml-1" />
                    <span className="text-[10px] font-black tracking-wide text-zinc-300 mt-1">انقر للتشغيل</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right side forwarding feedback animation */}
            <div className="absolute right-[10%] sm:right-[15%] pointer-events-none z-20">
              <AnimatePresence>
                {showForwardAnimation && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.4 }}
                    animate={{ opacity: 1, scale: 1.1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="flex flex-col items-center justify-center bg-black/85 text-white rounded-full w-20 h-20 border border-white/10 shadow-[0_0_30px_rgba(229,9,20,0.3)]"
                  >
                    <RotateCw className="w-8 h-8 text-primary animate-pulse" />
                    <span className="text-[10px] font-black tracking-wider mt-1">10+ ث</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Master custom controls layout (Premium Translucent Dashboard) */}
          <div 
            onClick={(e) => e.stopPropagation()}
            onMouseEnter={() => setIsHoveringControls(true)}
            onMouseLeave={() => setIsHoveringControls(false)}
            className={cn(
              "absolute inset-x-0 bottom-0 z-[120] p-1.5 transition-all duration-300 flex flex-col gap-1",
              showControls ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4 pointer-events-none"
            )}
          >
            <div className="bg-[#0c0c10]/95 backdrop-blur-2xl border border-white/5 rounded-lg p-1.5 flex flex-col gap-1 shadow-[0_24px_60px_rgba(0,0,0,0.95)]">
              
              {/* Timeline slider row */}
              <div className="flex flex-col gap-1 w-full">
                <div 
                  onClick={handleSeek}
                  className="h-1.5 w-full bg-zinc-900/90 border border-white/[0.03] rounded-full cursor-pointer relative group/timeline"
                >
                  {/* Crimson Progress fill */}
                  <div 
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-red-600 to-[#E50914] shadow-[0_0_12px_rgba(229,9,20,0.7)] rounded-full transition-all duration-75"
                    style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
                  />
                  
                  {/* Handle indicator */}
                  <div 
                    className="absolute top-1/2 -track-translate-y-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full border-2 border-primary scale-0 group-hover/timeline:scale-100 transition-transform duration-150 shadow-lg shadow-black/80"
                    style={{ left: `calc(${(currentTime / (duration || 1)) * 100}% - 6px)` }}
                  />
                </div>

                {/* Video Duration metrics */}
                <div className="flex justify-between text-[10px] font-black tracking-wider text-zinc-400 font-mono">
                  <span>{formatTime(duration)}</span>
                  <span>{formatTime(currentTime)}</span>
                </div>
              </div>

              {/* Functional Dashboard Options Row */}
              <div className="flex flex-col sm:flex-row gap-2 items-center justify-between">
                
                {/* Left controls: Volume, Play/Pause, Rewind, Fast Forward */}
                <div className="flex items-center gap-2 shrink-0">
                  <button 
                    onClick={handlePlayPause}
                    className="p-2 bg-primary hover:bg-[#c10d10] text-white rounded-full transition-all active:scale-95 shadow-lg shadow-primary/30"
                    title={isPlaying ? "إيقاف" : "تشغيل"}
                  >
                    {isPlaying ? <Pause className="w-4 h-4 animate-pulse" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                  </button>

                  <button 
                    onClick={(e) => skipTime(-10, e)}
                    className="p-1.5 text-zinc-400 hover:text-white transition-colors hover:scale-110 active:scale-95"
                    title="الرجوع 10 ثواني"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  <button 
                    onClick={(e) => skipTime(10, e)}
                    className="p-1.5 text-zinc-400 hover:text-white transition-colors hover:scale-110 active:scale-95"
                    title="التقديم 10 ثواني"
                  >
                    <RotateCw className="w-4 h-4" />
                  </button>

                  {/* Volume Controller with seamless popup */}
                  <div className="flex items-center gap-1.5 group/volume pl-1 border-l border-white/5">
                    <button 
                      onClick={toggleMute}
                      className="p-1 text-zinc-400 hover:text-white transition-colors"
                    >
                      {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-zinc-500" /> : <Volume2 className="w-4 h-4 text-primary" />}
                    </button>
                    <input 
                      type="range" 
                      min="0" 
                      max="1" 
                      step="0.05"
                      value={isMuted ? 0 : volume}
                      onChange={handleVolumeChange}
                      className="w-12 accent-primary h-1 bg-zinc-805 rounded-lg cursor-pointer transition-all opacity-40 group-hover/volume:opacity-100 focus:opacity-100"
                    />
                  </div>
                </div>

                {/* Right controls: Speed Modifier, Episode List toggle, Fullscreen */}
                <div className="flex items-center gap-2 shrink-0">
                  
                  {/* Playback rate settings menu switcher */}
                  <div className="relative">
                    <button 
                      onClick={(e) => { e.stopPropagation(); setShowSpeedMenu(!showSpeedMenu); setShowEpisodeMenu(false); }}
                      className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 text-[9px] font-black uppercase tracking-wider transition-all"
                    >
                      <Settings className="w-3 h-3 text-zinc-400 animate-spin-slow" />
                      {playbackRate}x
                    </button>

                    {showSpeedMenu && (
                      <div className="absolute bottom-full mb-2 left-0 w-24 bg-[#0a0a0d]/95 backdrop-blur-2xl border border-white/10 rounded-xl overflow-hidden shadow-2xl z-40 flex flex-col p-1">
                        <dic className="text-[8px] text-zinc-500 font-black tracking-widest uppercase p-1 border-b border-white/5 text-center mb-0.5">السرعة</dic>
                        {[0.5, 1, 1.25, 1.5, 2].map(speed => (
                          <button
                            key={speed}
                            onClick={() => handleSpeedChange(speed)}
                            className={cn(
                              "w-full text-center py-1.5 rounded-md text-[10px] font-bold transition-all px-2 text-right",
                              playbackRate === speed ? "bg-primary text-white" : "hover:bg-white/5 text-zinc-400"
                            )}
                          >
                            {speed}x
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Fully polished EPISODES Switcher drawer */}
                  <button
                    onClick={(e) => { e.stopPropagation(); setShowEpisodeMenu(!showEpisodeMenu); setShowSpeedMenu(false); }}
                    className="flex items-center gap-1 bg-primary/10 hover:bg-primary/20 p-2 rounded-lg border border-primary/20 text-white font-extrabold text-[9px] uppercase tracking-wider shadow-xl active:scale-95 transition-all animate-pulse"
                  >
                    <List className="w-3.5 h-3.5 text-primary" />
                    قائمة الحلقات
                  </button>

                  {/* Browser fullscreen trigger */}
                  <button 
                    onClick={toggleBrowserFullscreen}
                    className="p-1.5 text-zinc-400 hover:text-white hover:bg-white/5 rounded-lg transition-all border border-white/5"
                    title="ملئ الشاشة"
                  >
                    <Maximize className="w-4 h-4" />
                  </button>
                </div>

              </div>
            </div>
          </div>
        </>
      )}

      {/* EPISODE LIST OVERLAY */}
      <AnimatePresence>
        {showEpisodeMenu && (
          <motion.div
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, x: 80 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 80 }}
            className="absolute inset-y-0 right-0 w-80 max-w-[85vw] bg-black/95 backdrop-blur-3xl border-l border-white/10 z-[300] shadow-3xl flex flex-col p-6 overflow-hidden"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
              <div className="flex flex-col">
                <h3 className="text-sm font-black italic text-primary uppercase tracking-wider">CHOOSE EPISODE</h3>
                <span className="text-[10px] text-zinc-500 font-bold">قائمة الحلقات</span>
              </div>
              <button 
                onClick={() => setShowEpisodeMenu(false)}
                className="text-xs font-bold text-zinc-400 hover:text-white bg-white/5 border border-white/10 px-3 py-1.5 rounded-lg"
              >
                إغلاق
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-6 custom-scrollbar pr-1 pb-10">
              {/* SERVER SELECTOR */}
              <div>
                <h3 className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider mb-3 px-1">سيرفرات المشاهدة</h3>
                <div className="grid grid-cols-1 gap-2">
                  {servers.map((srv, idx) => (
                    <button 
                      key={idx} 
                      onClick={() => onSelectServer(srv.url)} 
                      className={cn(
                        "w-full text-right p-3 rounded-xl text-xs font-bold transition-all border",
                        srv.url === videoUrl 
                          ? "bg-primary border-primary text-white" 
                          : "bg-zinc-900/40 border-white/5 text-zinc-300 hover:bg-zinc-800"
                      )}
                    >
                      {srv.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* EPISODES */}
              <div>
                <h3 className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider mb-3 px-1">الحلقات</h3>
                <HorizontalEpisodeList 
                  episodes={episodes}
                  currentIndex={episodeIndex}
                  seriesImage={seriesImage}
                  seriesId={seriesId}
                  onSelect={(ep, idx) => onSelectEpisode(ep, idx)}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});

export default CustomPlayer;
