import { fetchAllFromFirebase } from './firebase';
import { decryptValue } from '../lib/security';

const API_BASE = '/api/v1/';

export interface ApiCategory {
  name: string;
  url: string;
}

export async function fetchCategories(): Promise<ApiCategory[]> {
  try {
    const res = await fetch(API_BASE + 'categories');
    const data = await res.json();
    if (data.status && data.data) {
      return data.data.map((cat: any) => ({
        ...cat,
        url: decryptValue(cat.url)
      }));
    }
  } catch (error) {
    console.error('API Categories Error:', error);
  }
  return [];
}

export async function fetchSeriesByCategory(categoryUrl: string) {
  try {
    const res = await fetch(API_BASE + 'series?url=' + encodeURIComponent(categoryUrl));
    const data = await res.json();
    if (data.status && data.data) {
      return data.data.map((s: any) => ({
        id: (s.url ? decryptValue(s.url) : s.title).replace(/[^a-zA-Z0-9]/g, '_'),
        title: s.title,
        image: s.image ? decryptValue(s.image) : '',
        url: s.url ? decryptValue(s.url) : '',
        episodes_count: s.episodes || '0',
        category: '',
        rating: 0,
        views: 0,
        episodes: [],
        trailer: ''
      }));
    }
  } catch (error) {
    console.error('API Series Error:', error);
  }
  return [];
}

export async function fetchAllFromAPI() {
  const allAvailableCategories = await fetchCategories();
  
  // All categories will be fetched
  const promises = allAvailableCategories.map(cat => fetchSeriesByCategory(cat.url));
  const results = await Promise.all(promises);
  
  const allSeriesMap = new Map<string, any>();
  
  results.forEach((series, catIndex) => {
    const originalCatName = allAvailableCategories[catIndex].name;
    
    // Determine the consolidated bucket
    let consolidatedCategory = '';
    if (originalCatName.includes('رمضان')) consolidatedCategory = 'رمضان';
    else if (originalCatName.includes('افلام')) consolidatedCategory = 'أفلام';
    else if (originalCatName.includes('كوريه') || originalCatName.includes('اسيوية') || originalCatName.includes('مسلسلات اجنبية')) consolidatedCategory = 'آسيوي وكوري';
    else if (originalCatName.includes('انمي')) consolidatedCategory = 'أنمي';
    else if (originalCatName.includes('تركي')) consolidatedCategory = 'تركي';
    else if (originalCatName.includes('خليجي')) consolidatedCategory = 'خليجي';
    else if (originalCatName.includes('عربي')) consolidatedCategory = 'عربي';
    else if (originalCatName.includes('فارسي')) consolidatedCategory = 'فارسي';
    else consolidatedCategory = originalCatName;
    
    series.forEach((s: any) => {
      // Use title as the unique key to deduplicate
      const key = s.title;
      const existing = allSeriesMap.get(key);
      
      if (existing) {
        // Series already exists in a previous category.
        // Append new category if different and not already present.
        if (existing.category && !existing.category.includes(consolidatedCategory)) {
          existing.category = `${existing.category}, ${consolidatedCategory}`;
        }
      } else {
        allSeriesMap.set(key, {
          ...s,
          category: consolidatedCategory
        });
      }
    });
  });

  // 2. نجيب Firebase
  const firebaseData = await fetchAllFromFirebase();
  
  // إزالة "حلم اشرف" من API لضمان استخدام نسخة Firebase
  const apiSeries = Array.from(allSeriesMap.values()).filter(s => !s.title.includes('حلم اشرف'));

  // عناوين API الحالية (للحروف الصغيرة، بدون "ال")
  const apiTitles = apiSeries.map(s => 
    s.title.toLowerCase().trim().replace(/^ال/, '')
  );

  // نضيف مسلسلات Firebase المو موجودة في API (مطابقة تامة فقط لتقليل الفلترة الزائدة)
  const newFromFB = firebaseData.filter(fb => {
    const fbTitle = fb.title.toLowerCase().trim().replace(/^ال/, '');
    // تأكد إن العنوان غير مطابق تماماً لأي من عناوين الـ API
    return !apiTitles.some(apiTitle => apiTitle === fbTitle);
  });

  // تحديد "حلم اشرف" من Firebase لإعطائه الأولوية
  const prioritySeries = newFromFB.filter(fb => fb.title.includes('حلم اشرف'));
  const otherSeries = [
    ...apiSeries, 
    ...newFromFB.filter(fb => !fb.title.includes('حلم اشرف'))
  ];

  // دمج API + Firebase مع أولوية لـ "حلم اشرف"
  return [...prioritySeries, ...otherSeries];
}

export async function fetchEpisodesFromAPI(seriesUrl: string) {
  try {
    const res = await fetch(API_BASE + 'episodes?url=' + encodeURIComponent(seriesUrl));
    const data = await res.json();
    if (data.status && data.data) {
      return data.data.map((ep: any) => ({
        title: ep.name || '1',
        url: ep.url ? decryptValue(ep.url) : '',
        link1: ep.url ? decryptValue(ep.url) : '',
        link2: '',
        link3: ''
      }));
    }
  } catch (error) {
    console.error('API Episodes Error:', error);
  }
  return [];
}

export async function fetchPlayUrlFromAPI(episodeUrl: string) {
  try {
    const res = await fetch(API_BASE + 'play?url=' + encodeURIComponent(episodeUrl));
    const data = await res.json();
    if (data.status && data.player_url) {
      return decryptValue(data.player_url);
    }
  } catch (error) {
    console.error('API Play URL Error:', error);
  }
  return null;
}
