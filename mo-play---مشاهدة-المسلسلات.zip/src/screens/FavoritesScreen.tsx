import React from 'react';
import Header from '../components/Header';
import { Heart } from 'lucide-react';

export default function FavoritesScreen() {
  return (
    <div className="min-h-screen bg-[#050505]">
      <Header />
      <div className="flex flex-col items-center justify-center py-40">
        <Heart className="w-20 h-20 text-gray-800 mb-6" />
        <h2 className="text-2xl font-bold text-gray-500">قائمة المفضلة فارغة حالياً</h2>
        <p className="text-gray-600 mt-2">ابدأ بإضافة المسلسلات التي تحبها!</p>
      </div>
    </div>
  );
}
