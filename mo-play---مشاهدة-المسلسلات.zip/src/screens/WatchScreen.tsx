import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChevronRight, Share2, Heart, History } from 'lucide-react';
import EpisodeGrid from '../components/EpisodeGrid';
import CustomPlayer from '../components/CustomPlayer';
import Header from '../components/Header';
import { fetchEpisodesFromAPI, fetchPlayUrlFromAPI } from '../services/api';
import { Episode, Series } from '../services/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { progressService } from '../services/progressService';
import SeriesChat from '../components/SeriesChat';

export default function WatchScreen() {
  const location = useLocation();
  const navigate = useNavigate();
  const { series } = (location.state as { series: Series }) || {};
  
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [currentEpisode, setCurrentEpisode] = useState(0);
  const [videoUrl, setVideoUrl] = useState('');
  const [servers, setServers] = useState<{ name: string; url: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [showEpisodesList, setShowEpisodesList] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [playerTime, setPlayerTime] = useState(0);
  
  const playerRef = useRef<HTMLDivElement>(null);
  const playerControlRef = useRef<any>(null);

  // Esc key to exit maximized viewport mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMaximized) {
        setIsMaximized(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMaximized]);

  // Prevent background body scrolling when viewing in immersive maximized mode
  useEffect(() => {
    if (isMaximized) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMaximized]);

  useEffect(() => {
    if (!series) {
      navigate('/');
      return;
    }
    loadEpisodes();
  }, [series]);
  
  async function loadEpisodes() {
    let eps: Episode[] = [];
    
    if (series.url) {
      eps = await fetchEpisodesFromAPI(series.url);
    }
    
    if (eps.length === 0 && series.episodes) {
      eps = Array.isArray(series.episodes) 
        ? series.episodes 
        : Object.values(series.episodes);
    }
    
    // Filter duplicates if not "حلم اشرف" or "ليلى_مدبلج"
    let finalEps = eps;
    if (series.title !== "حلم اشرف" && series.title !== "ليلى_مدبلج") {
      const uniqueEps: Episode[] = [];
      const seenEpisodes = new Set();
      for (const ep of eps) {
        const key = `${ep.title}-${ep.link1 || ep.url}`;
        if (!seenEpisodes.has(key)) {
          uniqueEps.push(ep);
          seenEpisodes.add(key);
        }
      }
      finalEps = uniqueEps;
    }
    
    // Sort episodes numerically based on title, handling special keywords
    finalEps.sort((a, b) => {
      const getOrder = (title: string) => {
        if (title.includes('الاخيرة') || title.includes('الأخيرة')) return 9999;
        const num = parseInt(title);
        return isNaN(num) ? 0 : num;
      };
      
      const orderA = getOrder(a.title);
      const orderB = getOrder(b.title);
      
      if (orderA !== orderB) return orderA - orderB;
      return a.title.localeCompare(b.title);
    });
    
    setEpisodes(finalEps);
    if (finalEps.length > 0) {
      // Check last watched episode if any
      const savedIndex = localStorage.getItem(`mo_play_last_ep_${series.id}`);
      const indexToPlay = savedIndex ? parseInt(savedIndex) : 0;
      playEpisode(finalEps[indexToPlay] || finalEps[0], indexToPlay);
    }
    setLoading(false);
  }
  
  async function playEpisode(ep: Episode, index: number) {
    // Save progress of current episode
    if (episodes.length > 0) {
      progressService.markAsWatched(series.id, currentEpisode);
    }

    setCurrentEpisode(index);
    localStorage.setItem(`mo_play_last_ep_${series.id}`, index.toString());
    
    setVideoUrl(''); // Reset for loader
    
    let url = ep.link1 || ep.url;
    
    // Resolve player URL if it is not a direct stream (including disguised .jpg / .png image links)
    if (url && !url.includes('.mp4') && !url.includes('.m3u8') && !url.includes('.webm') && !url.includes('.ogg') && !url.includes('.jpg') && !url.includes('.png')) {
      const playUrl = await fetchPlayUrlFromAPI(url);
      if (playUrl) url = playUrl;
    }
    
    setVideoUrl(url);
    
    // Setup servers
    const srv = [
      { name: 'سيرفر رئيسي', url: ep.link1 || ep.url },
      { name: 'سيرفر احتياطي 1', url: ep.link2 || '' },
      { name: 'سيرفر احتياطي 2', url: ep.link3 || '' },
    ].filter(s => s.url);
    
    setServers(srv);

    // Scroll to player
    playerRef.current?.scrollIntoView({ behavior: 'smooth' });
  }

  if (!series) return null;
  
  return (
    <div className="min-h-screen bg-[#050505] pb-20">
      <Header />
      
      <div className="max-w-7xl mx-auto flex flex-col items-center">
        {/* Navigation Info */}
        <div className="w-full px-4 sm:px-8 py-3 sm:py-4 flex items-center justify-between text-gray-400 text-[10px] sm:text-sm">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate('/')} className="hover:text-white transition-colors">الرئيسية</button>
            <ChevronRight className="w-3 sm:w-4 h-3 sm:h-4 rotate-180" />
            <span className="text-white font-semibold truncate max-w-[120px] sm:max-w-none">{series.title}</span>
          </div>
        </div>

        {/* Professional Video Player Section */}
        <div 
          ref={playerRef}
          className={cn(
            "w-full transition-all duration-300",
            isMaximized 
              ? "fixed inset-0 w-screen h-screen z-[100]" 
              : "relative mb-6 sm:mb-8"
          )}
        >
          <CustomPlayer
            ref={playerControlRef}
            videoUrl={videoUrl}
            seriesId={series.id}
            seriesImage={series.image}
            episodeIndex={currentEpisode}
            episodes={episodes}
            servers={servers}
            onSelectEpisode={(ep, idx) => playEpisode(ep, idx)}
            onSelectServer={(url) => setVideoUrl(url)}
            isMaximized={isMaximized}
            onToggleMaximize={() => setIsMaximized(!isMaximized)}
            onTimeUpdate={(t) => setPlayerTime(t)}
          />
        </div>

        <div className="w-full px-4 sm:px-8 flex flex-col lg:flex-row gap-8 sm:gap-12">
          {/* Main Content (Player + Info) */}
          <div className="flex-1 space-y-8 sm:space-y-12">
            {/* Info Section */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-6">
              <div>
                <motion.div 
                   initial={{ x: 20, opacity: 0 }}
                   animate={{ x: 0, opacity: 1 }}
                   className="flex items-center gap-2 mb-2"
                >
                  <span className="bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded text-[8px] sm:text-[10px] font-black italic uppercase">Now Playing</span>
                </motion.div>
                <motion.h1 
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  className="text-3xl sm:text-5xl font-black-italic text-white"
                >
                  {series.title}
                </motion.h1>
                <p className="text-zinc-500 font-bold text-xs sm:text-sm mt-2 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                  {episodes[currentEpisode]?.title ? `الإطلالة: الحلقة ${episodes[currentEpisode].title}` : `الحلقة ${currentEpisode + 1}`}
                </p>
              </div>

              {/* Professional Chat Block */}
              <div className="w-full lg:w-[420px] h-[400px] lg:h-[450px] shrink-0 order-last lg:order-none">
                <SeriesChat 
                  seriesId={series.id} 
                  seriesTitle={series.title} 
                  seriesImage={series.image}
                  currentPlaybackTime={playerTime}
                  onSeekTo={(t) => playerControlRef.current?.seekTo(t)}
                />
              </div>
            </div>

            {/* Servers Section */}
            <section className="bg-zinc-900/30 p-5 sm:p-8 rounded-3xl border border-white/5">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-1 h-5 sm:h-6 bg-primary rounded-full" />
                <h2 className="text-lg sm:text-xl font-black-italic italic uppercase tracking-tight">سيرفرات المشاهدة</h2>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {servers.map((srv, idx) => (
                  <button 
                    key={idx} 
                    onClick={() => setVideoUrl(srv.url)} 
                    className={cn(
                      "w-full text-center p-4 rounded-xl text-xs sm:text-sm font-bold transition-all border",
                      srv.url === videoUrl 
                        ? "bg-primary border-primary text-white" 
                        : "bg-zinc-800/40 border-white/5 text-zinc-300 hover:bg-zinc-800 hover:border-white/10"
                    )}
                  >
                    {srv.name}
                  </button>
                ))}
              </div>
            </section>

            {/* Episodes Grid Section */}
            <section className="bg-zinc-900/30 p-5 sm:p-8 rounded-3xl border border-white/5">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-1 h-5 sm:h-6 bg-primary rounded-full" />
                <h2 className="text-lg sm:text-xl font-black-italic italic uppercase tracking-tight">قائمة الحلقات</h2>
              </div>
              <EpisodeGrid 
                episodes={episodes}
                currentIndex={currentEpisode}
                seriesId={series.id}
                onSelect={(ep, idx) => playEpisode(ep, idx)}
              />
            </section>
          </div>

          {/* Sidebar */}
          <aside className="w-full lg:w-96 flex flex-col gap-6">
            <div className="bg-gradient-to-br from-zinc-800/50 to-zinc-900/50 p-6 rounded-3xl border border-white/5">
               <div className="flex items-center gap-2 text-[10px] text-zinc-500 uppercase font-black tracking-widest mb-3">
                 <History className="w-3 h-3" />
                 DETAILS
               </div>
               <div className="space-y-3">
                 <div className="flex justify-between text-xs font-bold">
                    <span className="text-zinc-500 uppercase italic">Category</span>
                    <span className="text-white uppercase tracking-tighter shrink-0">{series.category || 'GENERAL'}</span>
                 </div>
                 <div className="flex justify-between text-xs font-bold">
                    <span className="text-zinc-500 uppercase italic">Rating</span>
                    <span className="text-yellow-400 shrink-0">⭐ {series.rating} / 10</span>
                 </div>
                 <div className="flex justify-between text-xs font-bold">
                    <span className="text-zinc-500 uppercase italic">Views</span>
                    <span className="text-white shrink-0">{series.views}</span>
                 </div>
               </div>
            </div>

          </aside>
        </div>
      </div>
    </div>
  );
}
